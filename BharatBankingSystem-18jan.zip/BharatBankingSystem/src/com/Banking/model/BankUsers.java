package com.Banking.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BankUsers {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int accountNo;
    private String firstName;
    private String lastName;
    private double balance;
    private String userEmail;
    private String password;
    private String gender;
    private String phoneNumber;
    private String aadharNo;

    public BankUsers() {
	// TODO Auto-generated constructor stub
    }

    public BankUsers(int accountNo, String firstName, String lastName, double balance, String userEmail,
	    String password, String gender, String phoneNumber, String aadharNo) {
	super();
	this.accountNo = accountNo;
	this.firstName = firstName;
	this.lastName = lastName;
	this.balance = balance;
	this.userEmail = userEmail;
	this.password = password;
	this.gender = gender;
	this.phoneNumber = phoneNumber;
	this.aadharNo = aadharNo;
    }

    public int getAccountNo() {
	return accountNo;
    }

    public void setAccountNo(int accountNo) {
	this.accountNo = accountNo;
    }

    public String getFirstName() {
	return firstName;
    }

    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }

    public String getLastName() {
	return lastName;
    }

    public void setLastName(String lastName) {
	this.lastName = lastName;
    }

    public double getBalance() {
	return balance;
    }

    public void setBalance(double balance) {
	this.balance = balance;
    }

    public String getUserEmail() {
	return userEmail;
    }

    public void setUserEmail(String userEmail) {
	this.userEmail = userEmail;
    }

    public String getPassword() {
	return password;
    }

    public void setPassword(String password) {
	this.password = password;
    }

    public String getGender() {
	return gender;
    }

    public void setGender(String gender) {
	this.gender = gender;
    }

    public String getPhoneNumber() {
	return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
    }

    public String getAadharNo() {
	return aadharNo;
    }

    public void setAadharNo(String aadharNo) {
	this.aadharNo = aadharNo;
    }

    @Override
    public String toString() {
	return "BankUsers [accountNo=" + accountNo + ", firstName=" + firstName + ", lastName=" + lastName
		+ ", balance=" + balance + ", userEmail=" + userEmail + ", password=" + password + ", gender=" + gender
		+ ", phoneNumber=" + phoneNumber + ", aadharNo=" + aadharNo + "]";
    }

}
