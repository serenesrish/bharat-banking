package com.Banking.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BeneficiaryDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int benFid;
    private int benAccNo;
    private String name;
    private String ifscno;
    private int userId;

    public BeneficiaryDetails(int benFid, int benAccNo, String name, String ifscno, int userId) {
	super();
	this.benFid = benFid;
	this.benAccNo = benAccNo;
	this.name = name;
	this.ifscno = ifscno;
	this.userId = userId;
    }

    public BeneficiaryDetails() {
	// TODO Auto-generated constructor stub
    }

    public int getBenFid() {
	return benFid;
    }

    public void setBenFid(int benFid) {
	this.benFid = benFid;
    }

    public int getBenAccNo() {
	return benAccNo;
    }

    public void setBenAccNo(int benAccNo) {
	this.benAccNo = benAccNo;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getIfscno() {
	return ifscno;
    }

    public void setIfscno(String ifscno) {
	this.ifscno = ifscno;
    }

    public int getUserId() {
	return userId;
    }

    public void setUserId(int userId) {
	this.userId = userId;
    }

    @Override
    public String toString() {
	return "BeneficiaryDetails [benFid=" + benFid + ", benAccNo=" + benAccNo + ", name=" + name + ", ifscno="
		+ ifscno + ", userId=" + userId + "]";
    }

}
