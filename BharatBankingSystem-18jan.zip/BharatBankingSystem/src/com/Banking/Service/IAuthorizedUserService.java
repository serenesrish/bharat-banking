package com.Banking.Service;

import com.Banking.model.BeneficiaryDetails;

public interface IAuthorizedUserService {

    boolean verifyUser(String username, String password);

    void beneficiary(BeneficiaryDetails benfdetails);

}
