package com.Banking.Service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Banking.Dao.IAuthorizedUserDao;
import com.Banking.model.BeneficiaryDetails;

@Service
@Transactional
public class AuthorizedUserServiceImpl implements IAuthorizedUserService {

    @Autowired
    IAuthorizedUserDao authdao;

    @Override
    public boolean verifyUser(String username, String password) {

	return authdao.verifyUser(username, password);
    }

    @Override
    public void beneficiary(BeneficiaryDetails benfdetails) {
	// TODO Auto-generated method stub

    }

}
