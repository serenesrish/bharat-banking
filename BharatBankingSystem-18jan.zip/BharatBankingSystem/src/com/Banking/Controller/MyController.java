package com.Banking.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.Banking.Service.IAuthorizedUserService;
import com.Banking.model.BankUsers;
import com.Banking.model.BeneficiaryDetails;

@Controller
public class MyController {

    @Autowired
    IAuthorizedUserService authser;

    @RequestMapping("/LoginView")
    public String showLoginView(Model modal) {

	String view = "LoginView";
	return view;
    }

    @RequestMapping(value = "/LoginVerification", method = RequestMethod.POST)
    public String LoginValidation(Model model, HttpServletRequest req, HttpSession s) {

	String username = req.getParameter("username");
	System.out.println(username);
	String password = req.getParameter("password");
	System.out.println(password);
	s.setAttribute("username", username);
	/* model.addAttribute("username", username); */

	// System.out.println("this is password"+password);
	if (authser.verifyUser(username, password))

	{
	    System.out.println("inside");
	    return "dashboard";
	}
	return "LoginView";

    }

    /*
     * @RequestMapping(value = "/registerPage", method = RequestMethod.POST) public
     * String validateregistrationPage(@Valid @ModelAttribute("authuser") User user,
     * BindingResult bindingResult, Model model, HttpServletRequest req) {
     * 
     * String view = ""; if (bindingResult.hasErrors()) { view = "LoginView"; return
     * view; } else { UserService.AddUser(user);
     * 
     * return "redirect:/"; } }
     */

    @RequestMapping("/addBeneficiary")
    public String addBeneficiary(Model modal) {
	modal.addAttribute("benfdetails", new BankUsers());
	String view = "addbeneficiary";
	return view;
    }

    @RequestMapping(value = "/registerPage", method = RequestMethod.POST)
    public String validateregistrationPage(@Valid @ModelAttribute("benfdetails") BeneficiaryDetails benfdetails,
	    BindingResult bindingResult, Model model, HttpServletRequest req) {

	String view = "";
	if (bindingResult.hasErrors()) {
	    view = "LoginView";
	    return view;
	} else {
	    authser.beneficiary(benfdetails);

	    return "redirect:/";
	}
    }

}
