package com.Banking.Dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Banking.model.BankUsers;
import com.Banking.model.BeneficiaryDetails;

@Repository
public class AuthorizedUserDaoImpl implements IAuthorizedUserDao {
    static Transaction tx;
    static Transaction tx1;
    private SessionFactory sessionFactory;

    @Autowired // if annotated as repository then dont need to put entries in .xml
    public void setSessionFactory(SessionFactory sf) {
	this.sessionFactory = sf;
    }

    @Override
    public boolean verifyUser(String username, String password) {

	System.out.println(username);
	System.out.println("fghfhfhfhf" + password);
	Session session = this.sessionFactory.openSession();
	String query = "From BankUsers a where a.userEmail = :username and a.password = :password";
	Query q = session.createQuery(query);
	q.setString("username", username);
	q.setString("password", password);
	List<BankUsers> list = q.list();

	if (list.size() == 0) {
	    return false;
	}
	session.close();
	return true;

    }

    @Override
    public void beneficiary(BeneficiaryDetails benfdetails) {
	// TODO Auto-generated method stub

    }
}
