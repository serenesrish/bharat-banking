package com.Banking.Dao;

import com.Banking.model.BeneficiaryDetails;

public interface IAuthorizedUserDao {

    boolean verifyUser(String username, String password);

    public void beneficiary(BeneficiaryDetails benfdetails);
}
